#!/bin/sh

while [ true ]
do
	/data/MQTTClient_publish > /data/mqtt.log
done
